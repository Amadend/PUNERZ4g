<?php
global $wp_customize;
$wp_customize->add_section(
	'newspaper_x_general_banners_controls',
	array(
		'title' => esc_html__( 'Banner Settings', 'newspaper-x' )
	)
);
